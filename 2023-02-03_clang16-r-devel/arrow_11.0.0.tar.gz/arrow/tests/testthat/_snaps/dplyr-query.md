# Scalars in expressions match the type of the field, if possible

    Expression int == "5" not supported in Arrow; pulling data into R

